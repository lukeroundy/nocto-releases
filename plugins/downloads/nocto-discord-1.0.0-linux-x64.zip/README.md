# Discord Rich Presence for Nocto

Shows "Streaming", "Recording" or "Streaming and recording" plus the elapsed time on your Discord profile while Nocto is live or recording.
Nothing is shown while Nocto is idle.

Install: File > Plugins... > Install from .zip..., pick this zip, restart Nocto. Settings: Plugins > Discord Rich Presence.

- Needs the Discord desktop app running on the same computer (Windows, or Linux incl. Flatpak / Snap). No sign-in, no token.
- If Discord is closed the plugin waits quietly and connects when it starts.
- "Include recording" off: only streams are shown.
- Application ID: Nocto's own by default (1566741696580948059). To use your own name and artwork, create an application at
  https://discord.com/developers/applications, paste its ID, and optionally the key of a Rich Presence art asset as "Large image".
