Vignette (sample shader) 1.0.0 - a Nocto video filter plugin (Windows and Linux).

Install: in Nocto open File > Plugins... > "Open user plugins folder", copy vignette.json and vignette.hlsl into
that folder, then enable it in the Plugins window (or restart Nocto). Add it to a source under Filters > Add video filter.

Docs: https://lukeroundy.github.io/nocto-releases/plugins.html
