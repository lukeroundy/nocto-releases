# Nocto Plugin SDK 1.1 (ABI 2)

Documentation: https://lukeroundy.github.io/nocto-releases/plugins.html

| Path | What |
|---|---|
| `include/nocto_plugin.h` | the complete plugin C ABI (only depends on `<stdint.h>`) |
| `samples/sample_source/` | C++ DLL sample: Color Bars source, Simple Gain audio filter, Frame Counter output, hotkey |
| `samples/shader_vignette/` | shader-only video filter sample (`vignette.json` + `vignette.hlsl`, no compiler needed) |
| `template/my_plugin.cpp` | starting point: Invert video filter (D3D11 pixel shader) + hotkey |
| `samples/api_demo/` | ABI 2 sample: a panel, menu item, settings, secrets, HTTP and a WebSocket |
| `samples/twitch/` | (SDK zip only; the repo has it in `plugins/twitch`) the complete Twitch plugin |
| `CMakeLists.txt` | builds the DLLs; `nocto_add_plugin()` helper for your own |

Build (Visual Studio 2022 / Build Tools with the C++ workload, CMake 3.20+):

    cmake -S . -B build -A x64
    cmake --build build --config Release
    cmake --install build --config Release     # optional: copies into %LOCALAPPDATA%\Nocto\plugins

Then restart Nocto (or enable the plugin in File > Plugins...).

ABI 2 (SDK 1.1) adds dock panels, menus, per-plugin settings and secrets, async HTTP and WebSocket, timers and stream state: see `docs/PLUGINS.md` ("ABI 2") and the comments in the header. The full Twitch plugin source is in `plugins/twitch` of the Nocto repository.

To share a plugin, zip the files (`name.dll`, `name.so`, `name.json`, `name.hlsl`, `README.md`; flat or one wrapping folder) and users can install it with File > Plugins... > Install from .zip. See "Installing plugins" in `docs/PLUGINS.md` for what a valid zip may contain.
