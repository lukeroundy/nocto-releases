// Nocto sample plugin (C++): "Color Bars" source, "Simple Gain" audio filter, "Frame Counter" output, "Toggle Bar" hotkey.
// Build: see docs/PLUGINS.md (Windows: any MSVC DLL that includes nocto_plugin.h, copy it to %LOCALAPPDATA%\Nocto\plugins;
// Linux: a shared library linked with -lGL, copy it to ~/.local/share/Nocto/plugins). The same source builds on both: the
// texture handles are D3D11 objects on Windows and plain OpenGL texture names on Linux (see nocto_plugin.h).
#include "nocto_plugin.h"
#ifdef _WIN32
#include <d3d11.h>
#else
#define GL_GLEXT_PROTOTYPES 1
#include <GL/gl.h>
#include <GL/glext.h>
#include <stdint.h>
#endif
#include <cmath>
#include <cstdio>
#include <vector>

static const nocto_host* g_host;
static volatile int g_showBar = 1;
static void Log(const char* m) { if (g_host) g_host->log(g_host->plugin, NOCTO_LOG_INFO, m); }

// ---------------- source: solid colour + moving bar (top 10%), CPU-filled BGRA texture ----------------
struct Bars {
#ifdef _WIN32
    ID3D11Device* dev; ID3D11Texture2D* tex = nullptr; ID3D11ShaderResourceView* srv = nullptr;
#else
    GLuint tex = 0;
#endif
    uint32_t w = 640, h = 360; uint32_t color; float speed; std::vector<uint32_t> px;
};
static const nocto_prop kBarsProps[] = {
    {"color", "Background", NOCTO_PROP_COLOR, float(0x3080FF), 0, float(0xFFFFFF)},
    {"speed", "Bar speed", NOCTO_PROP_FLOAT, 0.25f, 0.f, 2.f},
    {"width", "Width", NOCTO_PROP_INT, 640, 64, 1920},
};
static void BarsApply(Bars* b, const float* v) { b->color = (uint32_t)v[0]; b->speed = v[1]; b->w = (uint32_t)v[2] & ~1u; if (b->w < 64) b->w = 64; b->h = b->w * 9 / 16; }
static void* BarsCreate(void* device, const float* v) {
#ifdef _WIN32
    auto* b = new Bars{static_cast<ID3D11Device*>(device)};
    BarsApply(b, v);
    D3D11_TEXTURE2D_DESC td{b->w, b->h, 1, 1, DXGI_FORMAT_B8G8R8A8_UNORM, {1, 0}, D3D11_USAGE_DEFAULT, D3D11_BIND_SHADER_RESOURCE};
    if (FAILED(b->dev->CreateTexture2D(&td, nullptr, &b->tex)) || FAILED(b->dev->CreateShaderResourceView(b->tex, nullptr, &b->srv))) { delete b; return nullptr; }
#else
    (void)device;   // Linux: NULL; a GL 3.3 context is current
    auto* b = new Bars;
    BarsApply(b, v);
    glGenTextures(1, &b->tex); glBindTexture(GL_TEXTURE_2D, b->tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, (GLsizei)b->w, (GLsizei)b->h, 0, GL_BGRA, GL_UNSIGNED_BYTE, nullptr);
#endif
    b->px.resize(size_t(b->w) * b->h);
    char m[96]; snprintf(m, sizeof m, "Color Bars created %ux%u", b->w, b->h); Log(m);
    return b;
}
static void BarsDestroy(void* p) {
    auto* b = (Bars*)p;
#ifdef _WIN32
    if (b->srv) b->srv->Release(); if (b->tex) b->tex->Release();
#else
    if (b->tex) glDeleteTextures(1, &b->tex);
#endif
    delete b;
}
static void BarsUpdate(void* p, const float* v) { auto* b = (Bars*)p; b->color = (uint32_t)v[0]; b->speed = v[1]; }
static void* BarsRender(void* p, void* context, double t, uint32_t* w, uint32_t* h) {
    auto* b = (Bars*)p;
    const uint32_t bg = 0xFF000000u | b->color;
    const uint32_t barX = uint32_t(std::fmod(t * b->speed, 1.0) * b->w), barW = b->w / 16, barH = b->h / 10;
    for (uint32_t y = 0; y < b->h; ++y) {
        uint32_t* row = b->px.data() + size_t(y) * b->w;
        for (uint32_t x = 0; x < b->w; ++x) row[x] = (g_showBar && y < barH && x >= barX && x < barX + barW) ? 0xFFFFFFFFu : bg;
    }
    *w = b->w; *h = b->h;
#ifdef _WIN32
    static_cast<ID3D11DeviceContext*>(context)->UpdateSubresource(b->tex, 0, nullptr, b->px.data(), b->w * 4, 0);
    return b->srv;
#else
    (void)context;
    glBindTexture(GL_TEXTURE_2D, b->tex);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, (GLsizei)b->w, (GLsizei)b->h, GL_BGRA, GL_UNSIGNED_BYTE, b->px.data());
    return (void*)(uintptr_t)b->tex;   // GL texture name (the host restores its GL state afterwards)
#endif
}
static const nocto_source_desc kBars = {"color_bars", "Color Bars (sample)", kBarsProps, 3, BarsCreate, BarsDestroy, BarsUpdate, BarsRender};

// ---------------- audio filter: gain ----------------
static const nocto_prop kGainProps[] = {{"gain", "Gain (linear)", NOCTO_PROP_FLOAT, 1.f, 0.f, 4.f}};
struct Gain { uint32_t ch; };
static void* GainCreate(uint32_t, uint32_t ch) { return new Gain{ch}; }
static void GainDestroy(void* p) { delete (Gain*)p; }
static void GainProcess(void* p, float* x, uint32_t frames, const float* v) { const uint32_t n = frames * ((Gain*)p)->ch; for (uint32_t i = 0; i < n; ++i) x[i] *= v[0]; }
static const nocto_audio_filter_desc kGain = {"gain", "Simple Gain (sample)", kGainProps, 1, GainCreate, GainDestroy, GainProcess};

// ---------------- output: counts program frames / audio ----------------
struct Counter { unsigned long long frames = 0, samples = 0; uint32_t w = 0, h = 0; };
static void* CounterStart(void*, const float*) { Log("Frame Counter started"); return new Counter; }
static void CounterStop(void* p) {
    auto* c = (Counter*)p; char m[160];
    snprintf(m, sizeof m, "Frame Counter stopped: frames=%llu size=%ux%u audio_frames=%llu", c->frames, c->w, c->h, c->samples); Log(m);
    delete c;
}
static void CounterVideo(void* p, void*, void*, uint32_t w, uint32_t h, int64_t) { auto* c = (Counter*)p; c->frames++; c->w = w; c->h = h; }
static void CounterAudio(void* p, const float*, uint32_t frames, uint32_t, uint32_t, int64_t) { ((Counter*)p)->samples += frames; }
static const nocto_output_desc kCounter = {"frame_counter", "Frame Counter (sample)", nullptr, 0, CounterStart, CounterStop, CounterVideo, CounterAudio};

// ---------------- hotkey ----------------
static void ToggleBar(void*) { g_showBar = !g_showBar; Log(g_showBar ? "bar on" : "bar off"); }
static const nocto_hotkey_desc kToggle = {"toggle_bar", "Color Bars: toggle bar", ToggleBar, nullptr};

extern "C" NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI_V1; }
extern "C" NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    g_host = host;
    info->abi = NOCTO_PLUGIN_ABI_V1; info->name = "Sample Source"; info->version = "1.0.0"; info->author = "Nocto";
    info->description = "Sample C++ plugin: animated colour source, gain audio filter, frame-counter output, hotkey.";
    host->register_source(host->plugin, &kBars);
    host->register_audio_filter(host->plugin, &kGain);
    host->register_output(host->plugin, &kCounter);
    host->register_hotkey(host->plugin, &kToggle);
    return 1;
}
extern "C" NOCTO_EXPORT void nocto_plugin_unload(void) { g_host = nullptr; }