// ABI 2 sample: a dock panel (nocto_ui_v1), a menu, per-plugin settings, secret storage, async HTTP and a WebSocket.
// Build it like the other samples (a shared library exporting the three nocto_plugin_* functions) and drop it in <Nocto folder>/plugins.
// The "Self test" menu item exercises every API against the server named by the NOCTO_TEST_BASE environment variable (used by
// `nocto --test-plugins`); without it the panel simply shows the stream state and keeps a counter in the plugin's settings.
#include "nocto_plugin.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

static const nocto_host* g_host;
static const nocto_ui_v1* g_ui;
static const nocto_app_v1* g_app;
static const nocto_storage_v1* g_st;
static const nocto_net_v1* g_net;

static int g_counter = 0;
static char g_note[128] = "hello";
static bool g_crashNext = false;
static std::string g_base;
static int g_pending = 0, g_fail = 0;
static uint64_t g_ws = 0;

static void Log(const char* fmt, const char* a = "", const char* b = "") {
    char m[512]; snprintf(m, sizeof m, fmt, a, b); g_host->log(g_host->plugin, NOCTO_LOG_INFO, m);
}
static void Result(bool ok, const char* name, const char* detail = "") {
    if (!ok) g_fail++;
    Log("api_demo: %s %s", ok ? "PASS" : "FAIL", name); if (*detail) Log("api_demo:   %s", detail);
}
static void Finish() { if (--g_pending == 0) Log("api_demo: DONE failures=%s", g_fail ? "yes" : "0"); }

static void SaveCounter() {
    char j[256]; snprintf(j, sizeof j, "{\"counter\":%d}", g_counter); g_st->settings_save(g_host->plugin, j);
}

static void DrawPanel(void*, const nocto_ui_v1* ui) {
    if (g_crashNext) {   // test: crash with ImGui scopes open - the host must unwind them and disable the plugin
        ui->push_id_str("crash"); ui->begin_child("c", 0, 40, 1); ui->push_text_color(NOCTO_RGBA(255, 0, 0, 255));
        *(volatile int*)0 = 1;
    }
    ui->separator_text("API demo");
    nocto_stream_state ss; memset(&ss, 0, sizeof ss); ss.size = sizeof ss;
    if (g_app->get_stream_state(g_host->plugin, &ss)) {
        ui->text(ss.streaming ? "Streaming: yes" : "Streaming: no");
        ui->text(ss.recording ? "Recording: yes" : "Recording: no");
    }
    ui->text("Note");
    ui->set_next_item_width(-8);   // narrow dock: full-width fields with the label above them
    ui->input_text("##note", g_note, sizeof g_note, 0, "type here");
    char l[64]; snprintf(l, sizeof l, "Counter: %d", g_counter); ui->text(l);
    if (ui->button("+1", 40, 0)) { g_counter++; SaveCounter(); }
    ui->tooltip("Saved in this plugin's settings");
    if (ui->button("Open Nocto site", -8, 0)) g_app->open_url(g_host->plugin, "https://lukeroundy.github.io/nocto-releases/");
}
static void MenuSelfTest(void*);
static void MenuCrash(void*) { g_crashNext = true; }

// ---- self test --------------------------------------------------------------------------------------------------------
static void OnHttp(void* user, const nocto_http_response* r) {
    const char* name = (const char*)user; const std::string n = name; char d[256];
    snprintf(d, sizeof d, "status=%d err=%s body=%.80s", r->status, r->error ? r->error : "-", r->body ? r->body : "");
    if (n == "http get") Result(r->status == 200 && !strcmp(r->body, "hello") && strstr(r->headers, "x-demo: yes"), "http get 200 + body + lower-cased header", d);
    else if (n == "http 400") Result(r->status == 400 && !strcmp(r->body, "bad request body"), "http 400 error body delivered", d);
    else if (n == "http redirect") Result(r->status == 200 && !strcmp(r->body, "hello"), "http 302 redirect followed", d);
    else if (n == "http chunked") Result(r->status == 200 && !strcmp(r->body, "chunk1chunk2chunk3"), "http chunked response decoded", d);
    else if (n == "http post") Result(r->status == 200 && !strcmp(r->body, "{\"a\":1} via PATCH tok=abc"), "http PATCH body + request header sent", d);
    else if (n == "http refused") Result(r->status == 0 && r->error && *r->error, "connection refused -> status 0 + error", d);
    Finish();
}
static void Get(const char* name, const char* method, const std::string& url, const char* headers, const char* body) {
    nocto_http_request q; memset(&q, 0, sizeof q); q.method = method; q.url = url.c_str(); q.headers = headers; q.body = body; q.body_len = body ? (uint32_t)strlen(body) : 0; q.timeout_ms = 5000;
    g_pending++;
    if (!g_net->http_request(g_host->plugin, &q, OnHttp, (void*)name)) { Result(false, name, "could not start"); Finish(); }
}
static void WsOpen(void*) { g_net->ws_send(g_host->plugin, g_ws, "ping", 4, 1); }
static void WsMsg(void*, const char* d, uint32_t n, int text) {
    static int step = 0;
    if (step == 0) { Result(text && n == 9 && !strncmp(d, "echo:ping", 9), "ws text echo", std::string(d, n).c_str()); step = 1; const unsigned char b[3] = {1, 2, 3}; g_net->ws_send(g_host->plugin, g_ws, b, 3, 0); }
    else if (step == 1) { Result(!text && n == 3 && d[0] == 1 && d[2] == 3, "ws binary echo"); step = 2; g_net->ws_send(g_host->plugin, g_ws, "close", 5, 1); }
}
static void WsClose(void*, int32_t code, const char* reason) {
    char d[200]; snprintf(d, sizeof d, "code=%d reason=%s", (int)code, reason ? reason : "");
    Result(code == 4000 && reason && !strcmp(reason, "bye"), "ws server close frame (code + reason)", d); Finish();
}
static void WsFailClose(void*, int32_t code, const char*) { Result(code == 1006, "ws connect failure -> on_close 1006"); Finish(); }

static void MenuSelfTest(void*) {
#ifdef _WIN32
    { char b[512]; const DWORD n = GetEnvironmentVariableA("NOCTO_TEST_BASE", b, sizeof b); g_base = (n > 0 && n < sizeof b) ? b : ""; }   // a DLL's static CRT does not see later SetEnvironmentVariable calls
#else
    g_base = getenv("NOCTO_TEST_BASE") ? getenv("NOCTO_TEST_BASE") : "";
#endif
    g_fail = 0;
    // API discovery
    Result(g_host->get_api(g_host->plugin, "nocto.nothing", 1) == nullptr, "get_api: unknown name -> NULL");
    Result(g_host->get_api(g_host->plugin, "nocto.ui", 99) == nullptr, "get_api: unknown version -> NULL");
    // settings
    SaveCounter();
    char buf[64] = {}; const int n = g_st->settings_load(g_host->plugin, buf, sizeof buf);
    Result(n > 0 && strstr(buf, "counter"), "settings save/load round trip", buf);
    // secrets
    const char* key = "token.test_1";
    Result(g_st->secret_set(g_host->plugin, key, "s3cr3t-value") == 1, "secret_set");
    char sv[64] = {}; const int sn = g_st->secret_get(g_host->plugin, key, sv, sizeof sv);
    Result(sn == 12 && !strcmp(sv, "s3cr3t-value"), "secret_get returns the value");
    Result(g_st->secret_set(g_host->plugin, "bad key!", "x") == 0, "secret_set rejects an invalid key");
    Result(g_st->secret_delete(g_host->plugin, key) == 1 && g_st->secret_get(g_host->plugin, key, sv, sizeof sv) < 0, "secret_delete");
    Result(g_app->open_url(g_host->plugin, "file:///etc/passwd") == 0 && g_app->open_url(g_host->plugin, "javascript:alert(1)") == 0, "open_url refuses non-http(s)");
    if (g_base.empty()) { Log("api_demo: DONE failures=%s", g_fail ? "yes" : "0 (no net server)"); return; }
    g_pending = 1;   // released at the end of this function
    Get("http get", "GET", g_base + "/ok", "X-Test: 1", nullptr);
    Get("http 400", nullptr, g_base + "/err", nullptr, nullptr);
    Get("http redirect", "GET", g_base + "/redir", nullptr, nullptr);
    Get("http chunked", "GET", g_base + "/chunked", nullptr, nullptr);
    Get("http post", "PATCH", g_base + "/echo", "Authorization: Bearer abc\nContent-Type: application/json", "{\"a\":1}");
    Get("http refused", "GET", "http://127.0.0.1:1/x", nullptr, nullptr);
    std::string ws = g_base; ws.replace(0, 4, "ws"); ws += "/ws";
    static nocto_ws_events ev; ev.on_open = WsOpen; ev.on_message = WsMsg; ev.on_close = WsClose; ev.user = nullptr;
    g_pending++;
    g_ws = g_net->ws_open(g_host->plugin, ws.c_str(), "X-Test: ws", &ev);
    if (!g_ws) { Result(false, "ws_open"); Finish(); }
    static nocto_ws_events ev2; ev2.on_close = WsFailClose;
    g_pending++;
    if (!g_net->ws_open(g_host->plugin, "ws://127.0.0.1:1/none", nullptr, &ev2)) { Result(false, "ws_open (refused)"); Finish(); }
    Finish();
}

extern "C" {
NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI; }
NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    g_host = host;
    info->abi = NOCTO_PLUGIN_ABI; info->name = "API Demo"; info->version = "1.0.0"; info->author = "Nocto";
    info->description = "Sample for plugin ABI 2: dock panel, menu, settings, secrets, HTTP and WebSocket.";
    if (host->abi < 2 || !host->get_api) return 0;
    g_ui = (const nocto_ui_v1*)host->get_api(host->plugin, "nocto.ui", 1);
    g_app = (const nocto_app_v1*)host->get_api(host->plugin, "nocto.app", 1);
    g_st = (const nocto_storage_v1*)host->get_api(host->plugin, "nocto.storage", 1);
    g_net = (const nocto_net_v1*)host->get_api(host->plugin, "nocto.net", 1);
    if (!g_ui || !g_app || !g_st || !g_net) return 0;
    char buf[256] = {};
    if (g_st->settings_load(host->plugin, buf, sizeof buf) > 0) { const char* p = strstr(buf, "\"counter\":"); if (p) g_counter = atoi(p + 10); }
    nocto_panel_desc pd; memset(&pd, 0, sizeof pd);
    pd.id = "main"; pd.title = "API Demo"; pd.dock = NOCTO_DOCK_RIGHT; pd.default_open = 0; pd.default_w = 320; pd.default_h = 240; pd.draw = DrawPanel;
    g_app->register_panel(host->plugin, &pd);
    nocto_menu_item_desc mi; memset(&mi, 0, sizeof mi);
    mi.menu = "API Demo"; mi.label = "Self test"; mi.clicked = MenuSelfTest; g_app->register_menu_item(host->plugin, &mi);
    mi.label = "Crash in panel (test)"; mi.clicked = MenuCrash; g_app->register_menu_item(host->plugin, &mi);
    return 1;
}
NOCTO_EXPORT void nocto_plugin_unload(void) {}
}
