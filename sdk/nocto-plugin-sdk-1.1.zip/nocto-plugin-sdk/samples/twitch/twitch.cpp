// Nocto Twitch plugin (plugin ABI 2): sign in with Twitch (OAuth Device Code flow, public client: Client ID only, no secret),
// a stream info editor (title, category with search, tags) and a chat dock (EventSub WebSocket, messages sent through Helix,
// anonymous read-only IRC fallback). Tokens live in Nocto's secret storage (never in settings, never logged).
//
// Everything here runs on Nocto's UI thread (panel draws, menu callbacks, HTTP/WebSocket completions, timers): no locks needed.
#include "nocto_plugin.h"
#include "mini_json.h"
#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <string>
#include <vector>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif

// ---- the one public identifier of the Twitch application "Nocto" (Public client type; device code flow) ----
#define NOCTO_TWITCH_CLIENT_ID "xblm0rnumg79mx8oshmr3bbuk8husn"
static const char* kScopes = "channel:manage:broadcast user:read:chat user:write:chat";

namespace {
const nocto_host* H; const nocto_app_v1* App; const nocto_storage_v1* St; const nocto_net_v1* Net;
void* Me() { return H->plugin; }

// ------------------------------------------------------------------------------------------------ utilities
void Log(const char* fmt, ...) { char b[600]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a); H->log(Me(), NOCTO_LOG_INFO, b); }
std::string UrlEnc(const std::string& s) {
    std::string o; char b[4];
    for (unsigned char c : s) { if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c; else { snprintf(b, sizeof b, "%%%02X", c); o += b; } }
    return o;
}
size_t Utf8Len(const std::string& s) { size_t n = 0; for (unsigned char c : s) if ((c & 0xC0) != 0x80) n++; return n; }
int64_t Now() { return (int64_t)time(nullptr); }
std::string Trim(std::string s) { while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back(); size_t i = 0; while (i < s.size() && isspace((unsigned char)s[i])) i++; return s.substr(i); }
std::string GetEnv(const char* n) {
#ifdef _WIN32
    char b[512]; const DWORD k = GetEnvironmentVariableA(n, b, sizeof b); return (k > 0 && k < sizeof b) ? std::string(b) : std::string();
#else
    const char* v = getenv(n); return v ? v : "";
#endif
}

// ------------------------------------------------------------------------------------------------ endpoints
struct Endpoints { std::string id = "https://id.twitch.tv", api = "https://api.twitch.tv/helix", eventsub = "wss://eventsub.wss.twitch.tv/ws", irc = "wss://irc-ws.chat.twitch.tv:443"; bool test = false; };
Endpoints E;
void InitEndpoints() {
    // Tests only: point everything at a loopback mock server. Anything but http://127.0.0.1:<port> is ignored.
    const std::string b = GetEnv("NOCTO_TWITCH_TEST_BASE");
    if (b.rfind("http://127.0.0.1:", 0) == 0 && b.size() < 32 && b.find('/', 8) == std::string::npos) {
        E.id = b; E.api = b + "/helix"; E.eventsub = "ws://" + b.substr(7) + "/ws"; E.irc = "ws://" + b.substr(7) + "/irc"; E.test = true;
    }
}
bool AllowedWsUrl(const std::string& u) {
    if (E.test) return u.rfind("ws://127.0.0.1:", 0) == 0;
    return u.rfind("wss://eventsub.wss.twitch.tv/", 0) == 0 || u.rfind("wss://eventsub.wss.twitch.tv:", 0) == 0;
}
bool AllowedBrowserUrl(const std::string& u) { return u.rfind("https://", 0) == 0 || (E.test && u.rfind("http://127.0.0.1", 0) == 0); }

// ------------------------------------------------------------------------------------------------ HTTP helpers
using HttpFn = std::function<void(int status, const std::string& body)>;
void HttpTramp(void* u, const nocto_http_response* r) {
    auto* f = static_cast<HttpFn*>(u);
    (*f)(r->status, std::string(r->body ? r->body : "", r->body ? r->body_len : 0));
    delete f;
}
bool Http(const char* method, const std::string& url, const std::string& headers, const std::string& body, HttpFn cb) {
    nocto_http_request rq; memset(&rq, 0, sizeof rq);
    rq.method = method; rq.url = url.c_str(); rq.headers = headers.empty() ? nullptr : headers.c_str();
    rq.body = body.empty() ? nullptr : body.data(); rq.body_len = (uint32_t)body.size(); rq.timeout_ms = 20000;
    auto* f = new HttpFn(std::move(cb));
    if (!Net->http_request(Me(), &rq, HttpTramp, f)) { HttpFn g = std::move(*f); delete f; g(0, "could not start request"); return false; }
    return true;
}
mj::Val Json(const std::string& s) { mj::Val v; if (!mj::Parse(s, v)) v = mj::Val(); return v; }
std::string ErrMsg(int status, const std::string& body) {
    const mj::Val j = Json(body); std::string m = j["message"].str();
    if (m.empty()) m = j["error_description"].str();
    if (m.empty()) m = status == 0 ? (body.empty() ? "network error" : body) : "HTTP " + std::to_string(status);
    return m;
}

// ------------------------------------------------------------------------------------------------ state
enum class Auth { SignedOut, Starting, WaitUser, SignedIn };
struct Line { std::string name, text; uint32_t color = 0; bool system = false; };
struct Category { std::string id, name; };
struct Status { std::string text; bool error = false; };

struct Conn;   // a WebSocket connection (EventSub or IRC)
struct G {
    Auth auth = Auth::SignedOut; std::string authError;
    std::string access, refresh, userId, login, display; int64_t expiresAt = 0;
    // device flow
    std::string deviceCode, userCode, verifyUri; int64_t deviceExpiresAt = 0; int pollMs = 5000; int pollFails = 0; uint64_t pollTimer = 0; uint64_t flowGen = 0;
    // token refresh
    bool refreshing = false;
    struct Queued { std::string method, path, body; std::function<void(int, const std::string&)> cb; bool retried; };
    std::vector<Queued> waiting;
    // stream info editor
    char title[640] = ""; char tags[320] = ""; char search[96] = ""; std::string gameId, gameName;
    bool channelLoaded = false, loading = false, saving = false; Status status; std::vector<Category> results; uint64_t searchTimer = 0; uint64_t searchSeq = 0; bool searching = false;
    // chat
    std::deque<Line> lines; char input[520] = ""; bool stickBottom = true;
    enum class Chat { Off, Connecting, Live, LiveIrc, Reconnecting } chat = Chat::Off; std::string chatNote;
    Conn* es = nullptr; Conn* esNew = nullptr; Conn* irc = nullptr; int chatFails = 0; uint64_t chatTimer = 0; uint64_t watchdog = 0; bool wantChat = false;
    bool shuttingDown = false;
};
G g;

// ------------------------------------------------------------------------------------------------ persistence
void SaveSettings() {
    std::string j = "{\"user_id\":" + mj::Quote(g.userId) + ",\"login\":" + mj::Quote(g.login) + ",\"display_name\":" + mj::Quote(g.display) + ",\"expires_at\":" + std::to_string((long long)g.expiresAt) + "}";
    St->settings_save(Me(), j.c_str());
}
void SaveTokens() { if (!g.access.empty()) St->secret_set(Me(), "access_token", g.access.c_str()); if (!g.refresh.empty()) St->secret_set(Me(), "refresh_token", g.refresh.c_str()); }
std::string Secret(const char* key) {
    char buf[2600]; const int32_t n = St->secret_get(Me(), key, buf, sizeof buf);
    return (n > 0 && n < (int32_t)sizeof buf) ? std::string(buf, (size_t)n) : std::string();
}
void ChatSystem(const std::string& t);
void ChatDisconnect();
void ClearChannelUi() { g.title[0] = g.tags[0] = g.search[0] = 0; g.gameId.clear(); g.gameName.clear(); g.channelLoaded = g.loading = g.saving = false; g.results.clear(); g.status = {}; }
void SignOutLocal(const std::string& why) {
    ChatDisconnect();
    if (g.pollTimer) { App->cancel_task(Me(), g.pollTimer); g.pollTimer = 0; }
    g.flowGen++;
    St->secret_delete(Me(), "access_token"); St->secret_delete(Me(), "refresh_token");
    g.access.clear(); g.refresh.clear(); g.userId.clear(); g.login.clear(); g.display.clear(); g.expiresAt = 0;
    g.auth = Auth::SignedOut; g.authError = why; g.deviceCode.clear(); g.userCode.clear();
    SaveSettings(); ClearChannelUi();
    for (auto& q : g.waiting) q.cb(401, "signed out");
    g.waiting.clear(); g.refreshing = false;
}

// ------------------------------------------------------------------------------------------------ authenticated Helix calls
void StartRefresh();
void Api(const char* method, const std::string& path, const std::string& body, std::function<void(int, const std::string&)> cb, bool retried = false) {
    if (g.auth != Auth::SignedIn) { cb(0, "not signed in"); return; }
    if (!retried && Now() + 60 >= g.expiresAt) { g.waiting.push_back({method, path, body, std::move(cb), false}); StartRefresh(); return; }
    std::string hdr = "Authorization: Bearer " + g.access + "\nClient-Id: " NOCTO_TWITCH_CLIENT_ID;
    if (!body.empty()) hdr += "\nContent-Type: application/json";
    const std::string m = method;
    Http(method, E.api + path, hdr, body, [m, path, body, retried, cb](int status, const std::string& resp) mutable {
        if (status == 401 && !retried && g.auth == Auth::SignedIn) { g.waiting.push_back({m, path, body, std::move(cb), true}); g.expiresAt = 0; StartRefresh(); return; }
        cb(status, resp);
    });
}
void StartRefresh() {
    if (g.refreshing) return;
    if (g.refresh.empty()) { SignOutLocal("Please sign in again."); return; }
    g.refreshing = true;
    const std::string body = "grant_type=refresh_token&refresh_token=" + UrlEnc(g.refresh) + "&client_id=" NOCTO_TWITCH_CLIENT_ID;
    const uint64_t gen = g.flowGen;
    Http("POST", E.id + "/oauth2/token", "Content-Type: application/x-www-form-urlencoded", body, [gen](int status, const std::string& resp) {
        if (gen != g.flowGen) return;   // signed out meanwhile
        g.refreshing = false;
        const mj::Val j = Json(resp);
        if (status == 200 && !j["access_token"].str().empty()) {
            g.access = j["access_token"].str(); if (!j["refresh_token"].str().empty()) g.refresh = j["refresh_token"].str();
            g.expiresAt = Now() + (int64_t)j["expires_in"].num(3600); SaveTokens(); SaveSettings();
            auto q = std::move(g.waiting); g.waiting.clear();
            for (auto& x : q) Api(x.method.c_str(), x.path, x.body, std::move(x.cb), true);
        } else if (status == 400 || status == 401) {
            SignOutLocal("Your Twitch session expired. Please sign in again.");
        } else {
            auto q = std::move(g.waiting); g.waiting.clear();
            for (auto& x : q) x.cb(0, "network error while refreshing the Twitch session");
        }
    });
}

// ------------------------------------------------------------------------------------------------ channel info
void LoadChannel() {
    if (g.auth != Auth::SignedIn || g.loading) return;
    g.loading = true; g.status = {"Loading your channel...", false};
    const uint64_t gen = g.flowGen;
    Api("GET", "/channels?broadcaster_id=" + UrlEnc(g.userId), "", [gen](int status, const std::string& resp) {
        if (gen != g.flowGen) return;
        g.loading = false;
        const mj::Val j = Json(resp); const mj::Val& d = j["data"].at(0);
        if (status == 200 && !d.isNull()) {
            snprintf(g.title, sizeof g.title, "%s", d["title"].str().c_str());
            g.gameId = d["game_id"].str(); g.gameName = d["game_name"].str();
            std::string t; for (size_t i = 0; i < d["tags"].size(); i++) { if (i) t += ", "; t += d["tags"].at(i).str(); }
            snprintf(g.tags, sizeof g.tags, "%s", t.c_str());
            g.channelLoaded = true; g.status = {"Loaded from Twitch.", false};
        } else g.status = {"Could not load your channel: " + ErrMsg(status, resp), true};
    });
}
void FetchUser() {
    const uint64_t gen = g.flowGen;
    Api("GET", "/users", "", [gen](int status, const std::string& resp) {
        if (gen != g.flowGen) return;
        const mj::Val j = Json(resp); const mj::Val& d = j["data"].at(0);
        if (status == 200 && !d["id"].str().empty()) {
            g.userId = d["id"].str(); g.login = d["login"].str(); g.display = d["display_name"].str(); SaveSettings();
            LoadChannel();
        } else if (status != 401) { g.status = {"Signed in, but could not read your profile: " + ErrMsg(status, resp), true}; }
    });
}
// Twitch tags: up to 10, each up to 25 characters, letters and digits only (no spaces or symbols).
std::vector<std::string> CleanTags(const char* raw, bool* changed) {
    std::vector<std::string> out; std::string cur; bool ch = false;
    auto flush = [&] {
        if (cur.empty()) return;
        if (cur.size() > 25) { cur.resize(25); ch = true; }
        for (auto& o : out) if (o == cur) { cur.clear(); ch = true; return; }
        if (out.size() < 10) out.push_back(cur); else ch = true;
        cur.clear();
    };
    bool pendingSpace = false;   // a space inside a tag ("my tag") is dropped and reported; spaces around separators are just formatting
    for (const char* p = raw; ; p++) {
        const unsigned char c = (unsigned char)*p;
        if (c == 0 || c == ',' || c == ';' || c == '\n') { flush(); pendingSpace = false; if (!c) break; }
        else if (isalnum(c) || c >= 0x80) { if (pendingSpace) ch = true; pendingSpace = false; cur += (char)c; }
        else if (c == ' ' || c == '\t') { if (!cur.empty()) pendingSpace = true; }
        else ch = true;   // symbols are dropped
    }
    if (changed) *changed = ch;
    return out;
}
void SaveChannel() {
    if (g.auth != Auth::SignedIn || g.saving) return;
    const std::string title = Trim(g.title);
    if (Utf8Len(title) > 140) { g.status = {"The title is longer than 140 characters.", true}; return; }
    bool ch = false; const auto tags = CleanTags(g.tags, &ch);
    std::string body = "{\"title\":" + mj::Quote(title);
    if (!g.gameId.empty()) body += ",\"game_id\":" + mj::Quote(g.gameId);
    body += ",\"tags\":["; for (size_t i = 0; i < tags.size(); i++) { if (i) body += ","; body += mj::Quote(tags[i]); } body += "]}";
    g.saving = true; g.status = {"Updating...", false};
    const uint64_t gen = g.flowGen;
    Api("PATCH", "/channels?broadcaster_id=" + UrlEnc(g.userId), body, [gen, tags](int status, const std::string& resp) {
        if (gen != g.flowGen) return;
        g.saving = false;
        if (status == 204 || status == 200) {
            std::string t; for (size_t i = 0; i < tags.size(); i++) { if (i) t += ", "; t += tags[i]; }
            snprintf(g.tags, sizeof g.tags, "%s", t.c_str());
            g.status = {"Stream info updated.", false}; App->toast(Me(), "Twitch: stream info updated");
        } else g.status = {"Twitch refused the update: " + ErrMsg(status, resp), true};
    });
}
void DoSearch(void*) {
    g.searchTimer = 0;
    const std::string q = Trim(g.search);
    if (q.empty() || g.auth != Auth::SignedIn) { g.results.clear(); g.searching = false; return; }
    const uint64_t seq = ++g.searchSeq, gen = g.flowGen; g.searching = true;
    Api("GET", "/search/categories?first=10&query=" + UrlEnc(q), "", [seq, gen](int status, const std::string& resp) {
        if (gen != g.flowGen || seq != g.searchSeq) return;   // a newer search or a sign-out replaced this one
        g.searching = false; g.results.clear();
        if (status == 200) { const mj::Val j = Json(resp); for (size_t i = 0; i < j["data"].size() && i < 10; i++) g.results.push_back({j["data"].at(i)["id"].str(), j["data"].at(i)["name"].str()}); }
        else g.status = {"Category search failed: " + ErrMsg(status, resp), true};
    });
}
void SearchEdited() {
    if (g.searchTimer) App->cancel_task(Me(), g.searchTimer);
    g.searchTimer = App->post_to_ui_after(Me(), 350, DoSearch, nullptr);   // debounce
}

// ------------------------------------------------------------------------------------------------ sign in (device code flow)
void PollToken(void*);
void SchedulePoll(int ms) { if (g.pollTimer) App->cancel_task(Me(), g.pollTimer); g.pollTimer = App->post_to_ui_after(Me(), (uint32_t)ms, PollToken, nullptr); }
void SignInFailed(const std::string& why) { g.auth = Auth::SignedOut; g.authError = why; g.deviceCode.clear(); g.userCode.clear(); g.pollTimer = 0; }
void StartSignIn() {
    if (g.auth != Auth::SignedOut) return;
    g.auth = Auth::Starting; g.authError.clear(); const uint64_t gen = ++g.flowGen;
    const std::string body = "client_id=" NOCTO_TWITCH_CLIENT_ID "&scopes=" + UrlEnc(kScopes);
    Http("POST", E.id + "/oauth2/device", "Content-Type: application/x-www-form-urlencoded", body, [gen](int status, const std::string& resp) {
        if (gen != g.flowGen || g.auth != Auth::Starting) return;
        const mj::Val j = Json(resp);
        if (status != 200 || j["device_code"].str().empty() || j["user_code"].str().empty()) { SignInFailed("Could not start sign-in: " + ErrMsg(status, resp)); return; }
        g.deviceCode = j["device_code"].str(); g.userCode = j["user_code"].str(); g.verifyUri = j["verification_uri"].str();
        g.pollMs = std::max(1000, (int)j["interval"].num(5) * 1000); g.pollFails = 0;
        g.deviceExpiresAt = Now() + (int64_t)j["expires_in"].num(1800);
        g.auth = Auth::WaitUser; SchedulePoll(g.pollMs);
    });
}
void CancelSignIn() { if (g.auth == Auth::Starting || g.auth == Auth::WaitUser) { if (g.pollTimer) { App->cancel_task(Me(), g.pollTimer); g.pollTimer = 0; } g.flowGen++; g.auth = Auth::SignedOut; g.authError.clear(); g.deviceCode.clear(); g.userCode.clear(); } }
void PollToken(void*) {
    g.pollTimer = 0;
    if (g.auth != Auth::WaitUser) return;
    if (Now() >= g.deviceExpiresAt) { SignInFailed("The code expired. Click Sign in to get a new one."); return; }
    const uint64_t gen = g.flowGen;
    const std::string body = "client_id=" NOCTO_TWITCH_CLIENT_ID "&scopes=" + UrlEnc(kScopes) + "&device_code=" + UrlEnc(g.deviceCode) + "&grant_type=" + UrlEnc("urn:ietf:params:oauth:grant-type:device_code");
    Http("POST", E.id + "/oauth2/token", "Content-Type: application/x-www-form-urlencoded", body, [gen](int status, const std::string& resp) {
        if (gen != g.flowGen || g.auth != Auth::WaitUser) return;
        const mj::Val j = Json(resp);
        if (status == 200 && !j["access_token"].str().empty() && !j["refresh_token"].str().empty()) {
            g.access = j["access_token"].str(); g.refresh = j["refresh_token"].str(); g.expiresAt = Now() + (int64_t)j["expires_in"].num(3600);
            g.deviceCode.clear(); g.userCode.clear(); g.authError.clear(); g.auth = Auth::SignedIn; SaveTokens(); SaveSettings();
            Log("twitch: signed in");
            FetchUser(); return;
        }
        const std::string m = j["message"].str();
        if (status == 0) { if (++g.pollFails > 6) SignInFailed("Network error while waiting for approval."); else SchedulePoll(g.pollMs); return; }
        g.pollFails = 0;
        if (m == "authorization_pending") { SchedulePoll(g.pollMs); return; }
        if (m == "slow_down") { g.pollMs += 5000; SchedulePoll(g.pollMs); return; }
        if (m.find("access_denied") != std::string::npos) SignInFailed("Sign-in was declined on Twitch.");
        else if (m.find("expired") != std::string::npos || m.find("invalid device code") != std::string::npos) SignInFailed("The code expired. Click Sign in to get a new one.");
        else SignInFailed("Sign-in failed: " + ErrMsg(status, resp));
    });
}
void SignOut() {
    if (g.auth == Auth::SignedIn && !g.access.empty()) {   // best effort: tell Twitch to revoke the token
        Http("POST", E.id + "/oauth2/revoke", "Content-Type: application/x-www-form-urlencoded", "client_id=" NOCTO_TWITCH_CLIENT_ID "&token=" + UrlEnc(g.access), [](int, const std::string&) {});
    }
    SignOutLocal("");
    g.lines.clear();
}

// ------------------------------------------------------------------------------------------------ chat
struct Conn { uint64_t ws = 0; bool irc = false, reconnect = false, welcomed = false, intentional = false, closed = false; int keepaliveS = 10; int64_t lastMs = 0; std::string sid; std::string buf; uint64_t gen = 0; };
uint32_t ParseColor(const std::string& c) {
    if (c.size() == 7 && c[0] == '#') {
        unsigned v = 0; for (int i = 1; i < 7; i++) { char x = c[i]; v <<= 4; if (x >= '0' && x <= '9') v |= x - '0'; else if (x >= 'a' && x <= 'f') v |= x - 'a' + 10; else if (x >= 'A' && x <= 'F') v |= x - 'A' + 10; else return 0; }
        int r = (v >> 16) & 255, gg = (v >> 8) & 255, b = v & 255;
        if (0.2126 * r + 0.7152 * gg + 0.0722 * b < 90) { r = (r + 255) / 2; gg = (gg + 255) / 2; b = (b + 255) / 2; }   // keep dark colours readable
        return NOCTO_RGBA(r, gg, b, 255);
    }
    return 0;
}
void AddLine(Line l) {
    if (l.text.size() > 2000) l.text.resize(2000);
    g.lines.push_back(std::move(l)); while (g.lines.size() > 500) g.lines.pop_front();
}
void ChatSystem(const std::string& t) { Line l; l.system = true; l.text = t; AddLine(l); }
void ChatConnect();
void ScheduleChatReconnect();
void WsMessage(void* u, const char* data, uint32_t len, int is_text);
void WsOpen(void* u);
void WsClose(void* u, int32_t code, const char* reason);
Conn* OpenWs(const std::string& url, bool irc, bool reconnect) {
    auto* c = new Conn(); c->irc = irc; c->reconnect = reconnect; c->lastMs = App->now_ms(); c->gen = g.flowGen;
    static nocto_ws_events ev = {WsOpen, WsMessage, WsClose, nullptr};
    nocto_ws_events e = ev; e.user = c;
    c->ws = Net->ws_open(Me(), url.c_str(), nullptr, &e);
    if (!c->ws) { delete c; return nullptr; }
    return c;
}
void CloseConn(Conn*& c) { if (c) { c->intentional = true; if (c->ws && !c->closed) Net->ws_close(Me(), c->ws); } c = nullptr; }
void ChatDisconnect() {
    g.wantChat = false;
    if (g.chatTimer) { App->cancel_task(Me(), g.chatTimer); g.chatTimer = 0; }
    if (g.watchdog) { App->cancel_task(Me(), g.watchdog); g.watchdog = 0; }
    CloseConn(g.es); CloseConn(g.esNew); CloseConn(g.irc);
    g.chat = G::Chat::Off; g.chatFails = 0; g.chatNote.clear();
}
void StartIrc() {
    if (g.irc || g.login.empty()) return;
    g.irc = OpenWs(E.irc, true, false);
    if (g.chat != G::Chat::Live) g.chat = G::Chat::Connecting;
}
void Watchdog(void*) {
    g.watchdog = 0;
    if (!g.es || !g.es->welcomed) return;
    const int64_t limit = (int64_t)g.es->keepaliveS * 1500 + 3000;
    if (App->now_ms() - g.es->lastMs > limit) { Log("twitch: chat connection went quiet, reconnecting"); Net->ws_close(Me(), g.es->ws); return; }
    g.watchdog = App->post_to_ui_after(Me(), 3000, Watchdog, nullptr);
}
void Subscribe(Conn* c) {
    const std::string body = "{\"type\":\"channel.chat.message\",\"version\":\"1\",\"condition\":{\"broadcaster_user_id\":" + mj::Quote(g.userId) + ",\"user_id\":" + mj::Quote(g.userId) +
                             "},\"transport\":{\"method\":\"websocket\",\"session_id\":" + mj::Quote(c->sid) + "}}";
    const uint64_t gen = g.flowGen;
    Api("POST", "/eventsub/subscriptions", body, [c, gen](int status, const std::string& resp) {
        if (gen != g.flowGen || g.es != c || c->closed) return;
        if (status == 202 || status == 200) {
            g.chat = G::Chat::Live; g.chatFails = 0; g.chatNote.clear();
            if (g.irc) CloseConn(g.irc);
            return;
        }
        g.chatNote = "Live chat unavailable (" + ErrMsg(status, resp) + "). Showing read-only chat.";
        ChatSystem(g.chatNote); StartIrc();
    });
}
void HandleEventSub(Conn* c, const mj::Val& m) {
    const std::string type = m["metadata"]["message_type"].str();
    c->lastMs = App->now_ms();
    if (type == "session_welcome") {
        c->sid = m["payload"]["session"]["id"].str(); c->keepaliveS = std::max(10, (int)m["payload"]["session"]["keepalive_timeout_seconds"].num(10)); c->welcomed = true;
        if (c->reconnect) {   // subscriptions carry over to the new connection: switch and drop the old one
            Conn* old = g.es; g.es = c; if (g.esNew == c) g.esNew = nullptr; CloseConn(old);
            g.chat = G::Chat::Live; g.chatFails = 0;
        } else { g.es = c; Subscribe(c); }
        if (g.watchdog) App->cancel_task(Me(), g.watchdog);
        g.watchdog = App->post_to_ui_after(Me(), 3000, Watchdog, nullptr);
    } else if (type == "notification") {
        if (m["metadata"]["subscription_type"].str() != "channel.chat.message") return;
        const mj::Val& ev = m["payload"]["event"];
        Line l; l.name = ev["chatter_user_name"].str(); if (l.name.empty()) l.name = ev["chatter_user_login"].str();
        l.text = ev["message"]["text"].str(); l.color = ParseColor(ev["color"].str());
        if (!l.text.empty()) AddLine(l);
    } else if (type == "session_reconnect") {
        const std::string url = m["payload"]["session"]["reconnect_url"].str();
        if (!AllowedWsUrl(url) || g.esNew) return;
        g.esNew = OpenWs(url, false, true);
    } else if (type == "revocation") {
        g.chatNote = "Twitch revoked the chat subscription. Sign out and in again to restore live chat."; ChatSystem(g.chatNote); StartIrc();
    }
}
void SendIrc(Conn* c, const std::string& s) { Net->ws_send(Me(), c->ws, s.data(), (uint32_t)s.size(), 1); }
void HandleIrcLine(Conn* c, const std::string& line) {
    if (line.rfind("PING", 0) == 0) { SendIrc(c, "PONG :tmi.twitch.tv\r\n"); return; }
    std::string tags, rest = line;
    if (!rest.empty() && rest[0] == '@') { const size_t sp = rest.find(' '); if (sp == std::string::npos) return; tags = rest.substr(1, sp - 1); rest = rest.substr(sp + 1); }
    if (rest.find(" PRIVMSG ") == std::string::npos) return;
    const size_t colon = rest.find(" :", rest.find(" PRIVMSG ")); if (colon == std::string::npos) return;
    Line l; l.text = rest.substr(colon + 2);
    if (!rest.empty() && rest[0] == ':') { const size_t ex = rest.find('!'); if (ex != std::string::npos) l.name = rest.substr(1, ex - 1); }
    size_t i = 0;
    while (i < tags.size()) {
        size_t e = tags.find(';', i); if (e == std::string::npos) e = tags.size();
        const std::string kv = tags.substr(i, e - i); const size_t eq = kv.find('=');
        if (eq != std::string::npos) { const std::string k = kv.substr(0, eq), v = kv.substr(eq + 1); if (k == "display-name" && !v.empty()) l.name = v; else if (k == "color") l.color = ParseColor(v); }
        i = e + 1;
    }
    if (!l.text.empty() && l.text[0] == '\x01') return;   // CTCP (/me is shown as plain text below)
    if (!l.name.empty()) AddLine(l);
}
void WsOpen(void* u) {
    Conn* c = static_cast<Conn*>(u); c->lastMs = App->now_ms();
    if (c->irc) {
        char nick[40]; snprintf(nick, sizeof nick, "justinfan%u", 10000 + (unsigned)(App->now_ms() % 80000));   // anonymous, read-only: no token is ever sent
        SendIrc(c, "CAP REQ :twitch.tv/tags twitch.tv/commands\r\nPASS SCHMOOPIIE\r\nNICK " + std::string(nick) + "\r\nJOIN #" + g.login + "\r\n");
    }
}
void WsMessage(void* u, const char* data, uint32_t len, int is_text) {
    Conn* c = static_cast<Conn*>(u); if (!is_text || c->closed) return;
    c->lastMs = App->now_ms();
    if (c->irc) {
        if (c != g.irc) return;
        c->buf.append(data, len); size_t p;
        while ((p = c->buf.find("\r\n")) != std::string::npos) { std::string line = c->buf.substr(0, p); c->buf.erase(0, p + 2); if (line.find(" 001 ") != std::string::npos) { if (g.chat != G::Chat::Live) { g.chat = G::Chat::LiveIrc; if (g.chatNote.empty()) g.chatNote = "Read-only chat (live connection unavailable)."; } } HandleIrcLine(c, line); }
        if (c->buf.size() > 65536) c->buf.clear();
        return;
    }
    if (c != g.es && c != g.esNew) return;
    mj::Val m; if (!mj::Parse(std::string(data, len), m)) return;
    HandleEventSub(c, m);
}
void ChatReconnectTick(void*) { g.chatTimer = 0; if (g.wantChat && g.auth == Auth::SignedIn && !g.es) ChatConnect(); }
void ScheduleChatReconnect() {
    if (!g.wantChat || g.auth != Auth::SignedIn || g.chatTimer) return;
    const int secs = std::min(30, 1 << std::min(g.chatFails, 5));
    g.chat = G::Chat::Reconnecting;
    g.chatTimer = App->post_to_ui_after(Me(), (uint32_t)secs * 1000, ChatReconnectTick, nullptr);
}
void WsClose(void* u, int32_t code, const char* reason) {
    Conn* c = static_cast<Conn*>(u); c->closed = true;
    (void)code; (void)reason;
    const bool wasEs = (c == g.es), wasNew = (c == g.esNew), wasIrc = (c == g.irc);
    if (wasEs) g.es = nullptr; if (wasNew) g.esNew = nullptr; if (wasIrc) g.irc = nullptr;
    const bool deliberate = c->intentional;
    delete c;
    if (deliberate || g.shuttingDown || !g.wantChat || g.auth != Auth::SignedIn) return;
    if (wasIrc) { if (!g.es) { g.chatFails++; if (g.chatFails > 8) { g.chat = G::Chat::Off; g.chatNote = "Chat disconnected."; } else { ScheduleChatReconnect(); } } return; }
    if (wasNew) return;   // a failed reconnect handover: keep the old session until it closes
    if (wasEs) {
        g.chatFails++;
        if (g.chatFails >= 3 && !g.irc) { g.chatNote = "Live chat connection failed. Showing read-only chat."; StartIrc(); }
        ScheduleChatReconnect();
    }
}
void ChatConnect() {
    if (g.auth != Auth::SignedIn || g.login.empty() || g.es) return;
    g.wantChat = true; if (g.chat == G::Chat::Off || g.chat == G::Chat::Reconnecting) g.chat = G::Chat::Connecting;
    g.es = OpenWs(E.eventsub, false, false);
    if (!g.es) { g.chatFails++; ScheduleChatReconnect(); }
}
void SendChat() {
    const std::string text = Trim(g.input);
    if (text.empty() || g.auth != Auth::SignedIn) return;
    if (Utf8Len(text) > 500) { ChatSystem("Message not sent: Twitch chat messages can be at most 500 characters."); return; }
    g.input[0] = 0;
    const bool echo = g.chat != G::Chat::Live && g.chat != G::Chat::LiveIrc;   // otherwise our own message comes back through the chat connection
    const std::string body = "{\"broadcaster_id\":" + mj::Quote(g.userId) + ",\"sender_id\":" + mj::Quote(g.userId) + ",\"message\":" + mj::Quote(text) + "}";
    const uint64_t gen = g.flowGen;
    Api("POST", "/chat/messages", body, [text, echo, gen](int status, const std::string& resp) {
        if (gen != g.flowGen) return;
        const mj::Val j = Json(resp); const mj::Val& d = j["data"].at(0);
        if (status == 200 && d["is_sent"].boolean()) { if (echo) { Line l; l.name = g.display; l.text = text; AddLine(l); } }
        else if (status == 200) ChatSystem("Message not sent: " + (d["drop_reason"]["message"].str().empty() ? std::string("dropped by Twitch") : d["drop_reason"]["message"].str()));
        else ChatSystem("Message not sent: " + ErrMsg(status, resp));
    });
}

// ------------------------------------------------------------------------------------------------ panels
const uint32_t kRed = NOCTO_RGBA(240, 100, 100, 255), kGreen = NOCTO_RGBA(110, 210, 130, 255), kAccent = NOCTO_RGBA(180, 140, 255, 255), kAmber = NOCTO_RGBA(240, 190, 90, 255), kDim = NOCTO_RGBA(128, 128, 140, 255);
void Dim(const nocto_ui_v1* ui, const char* t) { ui->push_text_color(kDim); ui->text_wrapped(t); ui->pop_text_color(); }   // wraps, so it never clips in a narrow dock or at 300% scale
char Remaining[32];
const char* CountDown(int64_t secs) { if (secs < 0) secs = 0; snprintf(Remaining, sizeof Remaining, "%lld:%02lld", (long long)(secs / 60), (long long)(secs % 60)); return Remaining; }

void DrawSignedOut(const nocto_ui_v1* ui) {
    ui->text_wrapped("Sign in to edit your stream title, category and tags, and to read and send chat without leaving Nocto.");
    ui->spacing();
    if (!g.authError.empty()) { ui->push_text_color(kRed); ui->text_wrapped(g.authError.c_str()); ui->pop_text_color(); ui->spacing(); }
    if (ui->button("Sign in with Twitch", -8, 0)) StartSignIn();
    ui->spacing();
    Dim(ui, "You approve the sign-in on twitch.tv. Nocto never sees your password.");
}
void DrawWaiting(const nocto_ui_v1* ui) {
    if (g.auth == Auth::Starting) { ui->text("Contacting Twitch..."); if (ui->button("Cancel", -8, 0)) CancelSignIn(); return; }
    ui->separator_text("Approve in your browser");
    ui->text_wrapped("1. Open the Twitch activation page.");
    if (ui->button("Open Twitch activation page", -8, 0)) { if (AllowedBrowserUrl(g.verifyUri)) App->open_url(Me(), g.verifyUri.c_str()); else App->open_url(Me(), "https://www.twitch.tv/activate"); }
    ui->text_wrapped("2. Sign in to Twitch and enter this code if it is not filled in:");
    ui->push_text_color(kAccent); ui->text(g.userCode.c_str()); ui->pop_text_color();
    if (ui->small_button("Copy code")) ui->set_clipboard(g.userCode.c_str());
    ui->spacing();
    char l[96]; snprintf(l, sizeof l, "Waiting for approval... code expires in %s", CountDown(g.deviceExpiresAt - Now())); Dim(ui, l);
    if (ui->button("Cancel", -8, 0)) CancelSignIn();
}
void DrawStatus(const nocto_ui_v1* ui) {
    if (g.status.text.empty()) return;
    ui->push_text_color(g.status.error ? kRed : kGreen); ui->text_wrapped(g.status.text.c_str()); ui->pop_text_color();
}
void DrawStreamInfo(const nocto_ui_v1* ui) {
    char who[160]; snprintf(who, sizeof who, "Signed in as %s", g.display.empty() ? g.login.c_str() : g.display.c_str()); ui->text_wrapped(who);
    if (ui->small_button("Sign out")) { SignOut(); return; }
    ui->same_line(0, 0); ui->text("  "); ui->same_line(0, 0);
    if (ui->small_button("Reload")) LoadChannel();
    ui->tooltip("Fetch the current title, category and tags from Twitch");
    ui->separator_text("Stream info");
    ui->begin_disabled(!g.channelLoaded && g.loading);
    ui->text("Title");
    ui->set_next_item_width(-8);
    ui->input_text("##title", g.title, sizeof g.title, 0, "What are you streaming?");
    { char c[32]; snprintf(c, sizeof c, "%zu / 140", Utf8Len(Trim(g.title))); if (Utf8Len(Trim(g.title)) > 140) { ui->push_text_color(kRed); ui->text(c); ui->pop_text_color(); } else Dim(ui, c); }
    ui->spacing();
    ui->text("Category");
    { std::string cur = g.gameName.empty() ? std::string("(none)") : g.gameName; ui->push_text_color(kAccent); ui->text_wrapped(cur.c_str()); ui->pop_text_color(); }
    ui->set_next_item_width(-8);
    if (ui->input_text("##cat", g.search, sizeof g.search, 0, "Search categories...")) SearchEdited();
    if (g.searching) Dim(ui, "Searching...");
    if (!g.results.empty()) {
        if (ui->begin_child("##catres", 0, std::min(150.0f, 28.0f * (float)g.results.size() + 8), 1)) {
            for (size_t i = 0; i < g.results.size(); i++) {
                ui->push_id_int((int)i);
                if (ui->selectable(g.results[i].name.c_str(), g.results[i].id == g.gameId)) { g.gameId = g.results[i].id; g.gameName = g.results[i].name; g.search[0] = 0; g.results.clear(); ui->pop_id(); break; }
                ui->pop_id();
            }
        }
        ui->end_child();
    } else if (g.search[0] && !g.searching && !g.searchTimer) Dim(ui, "No categories found.");
    ui->spacing();
    ui->text("Tags");
    ui->set_next_item_width(-8);
    ui->input_text("##tags", g.tags, sizeof g.tags, 0, "english, chill, gaming");
    bool ch = false; const auto tg = CleanTags(g.tags, &ch);
    { char c[96]; snprintf(c, sizeof c, "%zu of 10 tags. Letters and numbers only, up to 25 each.", tg.size()); Dim(ui, c); }
    if (ch) { ui->push_text_color(kAmber); ui->text_wrapped("Spaces and symbols will be removed when you update."); ui->pop_text_color(); }
    ui->end_disabled();
    ui->spacing();
    ui->begin_disabled(g.saving || g.loading || !g.channelLoaded);
    if (ui->button("Update stream info", -8, 0)) SaveChannel();
    ui->end_disabled();
    DrawStatus(ui);
}
void DrawStreamPanel(void*, const nocto_ui_v1* ui) {
    ui->separator_text("Twitch");
    if (g.auth == Auth::SignedOut) DrawSignedOut(ui);
    else if (g.auth == Auth::SignedIn) { if (!g.channelLoaded && !g.loading && g.status.text.empty()) LoadChannel(); DrawStreamInfo(ui); }
    else DrawWaiting(ui);
}
void DrawChatPanel(void*, const nocto_ui_v1* ui) {
    if (g.auth != Auth::SignedIn) {
        ui->text_wrapped("Sign in with Twitch to see your chat here.");
        if (g.auth == Auth::SignedOut) { if (ui->button("Sign in with Twitch", -8, 0)) { StartSignIn(); App->set_panel_open(Me(), "stream", 1); } }
        else Dim(ui, "Finish signing in in the Twitch panel.");
        return;
    }
    if (!g.wantChat && !g.es && !g.chatTimer) ChatConnect();
    const char* st = "Connecting..."; uint32_t col = kAmber;
    switch (g.chat) {
        case G::Chat::Live: st = "Connected"; col = kGreen; break;
        case G::Chat::LiveIrc: st = "Connected (read-only)"; col = kAmber; break;
        case G::Chat::Reconnecting: st = "Reconnecting..."; col = kAmber; break;
        case G::Chat::Off: st = "Disconnected"; col = kRed; break;
        default: break;
    }
    ui->text_colored(col, st); ui->same_line(0, 0); ui->text("  "); ui->same_line(0, 0);
    if (ui->small_button("Clear")) g.lines.clear();
    if (g.chat == G::Chat::LiveIrc && !g.chatNote.empty()) ui->tooltip(g.chatNote.c_str());
    float h = ui->content_height() - 44.0f; if (h < 60) h = 60;
    if (ui->begin_child("##chatlog", 0, h, 1)) {
        const bool atBottom = ui->scroll_y() >= ui->scroll_max_y() - 4.0f;
        for (size_t i = 0; i < g.lines.size(); i++) {
            const Line& l = g.lines[i];
            ui->push_id_int((int)i);
            if (l.system) { Dim(ui, l.text.c_str()); }
            else {
                ui->text_colored(l.color ? l.color : NOCTO_RGBA(200, 200, 210, 255), l.name.c_str()); ui->same_line(0, 0);
                ui->text_wrapped((": " + l.text).c_str());
            }
            ui->pop_id();
        }
        if (atBottom || g.stickBottom) { ui->set_scroll_here_y(1.0f); g.stickBottom = false; }
    }
    ui->end_child();
    ui->set_next_item_width(-60);
    if (ui->input_text("##send", g.input, sizeof g.input, NOCTO_INPUT_ENTER_RETURNS, "Send a message")) SendChat();
    ui->same_line(0, 0);
    if (ui->button("Send", 0, 0)) SendChat();
}

// ------------------------------------------------------------------------------------------------ menu
enum { M_SIGNIN = 1, M_SIGNOUT, M_STREAM, M_CHAT, M_CHANNEL, M_DASH };
uint32_t MenuState(void* u) {
    switch ((intptr_t)u) {
        case M_SIGNIN: return g.auth == Auth::SignedOut ? 0 : NOCTO_MENU_DISABLED;
        case M_SIGNOUT: return g.auth == Auth::SignedIn ? 0 : NOCTO_MENU_DISABLED;
        case M_STREAM: return App->is_panel_open(Me(), "stream") ? NOCTO_MENU_CHECKED : 0;
        case M_CHAT: return App->is_panel_open(Me(), "chat") ? NOCTO_MENU_CHECKED : 0;
        case M_CHANNEL: return g.auth == Auth::SignedIn ? 0 : NOCTO_MENU_DISABLED;
    }
    return 0;
}
void MenuClick(void* u) {
    switch ((intptr_t)u) {
        case M_SIGNIN: StartSignIn(); App->set_panel_open(Me(), "stream", 1); break;
        case M_SIGNOUT: SignOut(); break;
        case M_STREAM: App->set_panel_open(Me(), "stream", !App->is_panel_open(Me(), "stream")); break;
        case M_CHAT: App->set_panel_open(Me(), "chat", !App->is_panel_open(Me(), "chat")); break;
        case M_CHANNEL: { std::string u2 = "https://www.twitch.tv/" + g.login; if (!g.login.empty()) App->open_url(Me(), u2.c_str()); break; }
        case M_DASH: App->open_url(Me(), "https://dashboard.twitch.tv/stream-manager"); break;
    }
}

// Restores the session saved by a previous run: tokens from secret storage, the account from the plugin's settings.
void RestoreSession() {
    char sb[1024] = {}; if (St->settings_load(Me(), sb, sizeof sb) > 0) {
        const mj::Val j = Json(sb); g.userId = j["user_id"].str(); g.login = j["login"].str(); g.display = j["display_name"].str(); g.expiresAt = (int64_t)j["expires_at"].num(0);
    }
    g.access = Secret("access_token"); g.refresh = Secret("refresh_token");
    if (!g.refresh.empty() && !g.userId.empty()) g.auth = Auth::SignedIn; else { g.access.clear(); g.refresh.clear(); g.auth = Auth::SignedOut; }
}

// ------------------------------------------------------------------------------------------------ test hook (only when the mock server is configured)
std::string Esc(const std::string& s) { return mj::Quote(s); }
std::string g_testOut;
const char* TestCmd(const char* cmdc, const char* argc) {
    InitEndpoints(); if (!E.test) return "{}";
    const std::string cmd = cmdc ? cmdc : "", arg = argc ? argc : "";
    if (cmd == "signin") StartSignIn();
    else if (cmd == "cancel") CancelSignIn();
    else if (cmd == "signout") SignOut();
    else if (cmd == "reload") LoadChannel();
    else if (cmd == "set_title") snprintf(g.title, sizeof g.title, "%s", arg.c_str());
    else if (cmd == "set_tags") snprintf(g.tags, sizeof g.tags, "%s", arg.c_str());
    else if (cmd == "search") { snprintf(g.search, sizeof g.search, "%s", arg.c_str()); SearchEdited(); }
    else if (cmd == "pick") { const size_t i = (size_t)atoi(arg.c_str()); if (i < g.results.size()) { g.gameId = g.results[i].id; g.gameName = g.results[i].name; g.search[0] = 0; g.results.clear(); } }
    else if (cmd == "save") SaveChannel();
    else if (cmd == "chat") ChatConnect();
    else if (cmd == "send") { snprintf(g.input, sizeof g.input, "%s", arg.c_str()); SendChat(); }
    else if (cmd == "expire") g.expiresAt = 1;   // force a refresh on the next call
    else if (cmd == "chat_off") ChatDisconnect();
    else if (cmd == "restart") { ChatDisconnect(); const uint64_t gen = g.flowGen + 1; const bool sd = g.shuttingDown; g = G(); g.flowGen = gen; g.shuttingDown = sd; RestoreSession(); }
    std::string lines = "[";
    for (size_t i = g.lines.size() > 12 ? g.lines.size() - 12 : 0; i < g.lines.size(); i++) { if (lines.size() > 1) lines += ","; lines += Esc(g.lines[i].system ? "* " + g.lines[i].text : g.lines[i].name + ": " + g.lines[i].text); }
    lines += "]";
    std::string res = "["; for (size_t i = 0; i < g.results.size(); i++) { if (i) res += ","; res += Esc(g.results[i].name); } res += "]";
    static const char* as[] = {"signed_out", "starting", "wait_user", "signed_in"}; static const char* cs[] = {"off", "connecting", "live", "live_irc", "reconnecting"};
    g_testOut = "{\"auth\":\"" + std::string(as[(int)g.auth]) + "\",\"error\":" + Esc(g.authError) + ",\"user\":" + Esc(g.login) + ",\"code\":" + Esc(g.userCode) + ",\"title\":" + Esc(g.title) + ",\"game\":" + Esc(g.gameName) +
                ",\"tags\":" + Esc(g.tags) + ",\"loaded\":" + (g.channelLoaded ? "true" : "false") + ",\"status\":" + Esc(g.status.text) + ",\"status_error\":" + (g.status.error ? "true" : "false") +
                ",\"results\":" + res + ",\"chat\":\"" + cs[(int)g.chat] + "\",\"lines\":" + lines + ",\"nlines\":" + std::to_string(g.lines.size()) + ",\"has_access\":" + (g.access.empty() ? "false" : "true") + "}";
    return g_testOut.c_str();
}
} // namespace

extern "C" {
NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI; }
NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    H = host;
    info->abi = NOCTO_PLUGIN_ABI; info->name = "Twitch"; info->version = "0.9.0"; info->author = "Nocto";
    info->description = "Sign in with Twitch, edit your stream title / category / tags and read and send chat from inside Nocto.";
    if (host->abi < 2 || !host->get_api) return 0;
    const nocto_ui_v1* ui = (const nocto_ui_v1*)host->get_api(host->plugin, "nocto.ui", 1); (void)ui;
    App = (const nocto_app_v1*)host->get_api(host->plugin, "nocto.app", 1);
    St = (const nocto_storage_v1*)host->get_api(host->plugin, "nocto.storage", 1);
    Net = (const nocto_net_v1*)host->get_api(host->plugin, "nocto.net", 1);
    if (!ui || !App || !St || !Net || App->size < sizeof(nocto_app_v1)) return 0;   // needs SDK 1.1 (timers)
    InitEndpoints();
    RestoreSession();
    nocto_panel_desc pd; memset(&pd, 0, sizeof pd);
    pd.id = "stream"; pd.title = "Twitch"; pd.dock = NOCTO_DOCK_RIGHT; pd.default_open = 1; pd.default_w = 320; pd.default_h = 520; pd.draw = DrawStreamPanel;
    App->register_panel(host->plugin, &pd);
    pd.id = "chat"; pd.title = "Twitch Chat"; pd.default_open = 0; pd.draw = DrawChatPanel;
    App->register_panel(host->plugin, &pd);
    nocto_menu_item_desc mi; memset(&mi, 0, sizeof mi); mi.menu = "Twitch"; mi.state = MenuState; mi.clicked = MenuClick;
    struct { const char* label; intptr_t id; } items[] = {{"Sign in with Twitch...", M_SIGNIN}, {"Sign out", M_SIGNOUT}, {"-", 0}, {"Stream info", M_STREAM}, {"Chat", M_CHAT}, {"-", 0}, {"Open my channel", M_CHANNEL}, {"Open Twitch dashboard", M_DASH}};
    for (auto& it : items) { mi.label = it.label; mi.user = (void*)it.id; App->register_menu_item(host->plugin, &mi); }
    if (E.test && !GetEnv("NOCTO_TWITCH_TEST_AUTOSIGNIN").empty() && g.auth == Auth::SignedOut) StartSignIn();   // layout/screenshot tests against the mock server
    Log("twitch: loaded (%s)", g.auth == Auth::SignedIn ? "signed in" : "signed out");
    return 1;
}
NOCTO_EXPORT void nocto_plugin_unload(void) { g.shuttingDown = true; }
NOCTO_EXPORT const char* nocto_twitch_test(const char* cmd, const char* arg) { return TestCmd(cmd, arg); }
}
