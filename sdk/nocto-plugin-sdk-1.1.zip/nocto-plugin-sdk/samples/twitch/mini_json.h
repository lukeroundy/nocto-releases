// Minimal JSON reader/writer helpers for the Twitch plugin (no dependencies). Not a general-purpose library: numbers are doubles,
// nesting is limited to 32 levels, input is limited to 1 MiB.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <utility>
#include <vector>

namespace mj {
struct Val {
    enum Type { Null, Bool, Num, Str, Arr, Obj } t = Null;
    bool b = false; double n = 0; std::string s;
    std::vector<Val> a; std::vector<std::pair<std::string, Val>> o;
    static const Val& None() { static const Val v; return v; }
    const Val& operator[](const char* k) const { if (t == Obj) for (auto& kv : o) if (kv.first == k) return kv.second; return None(); }
    const Val& at(size_t i) const { return (t == Arr && i < a.size()) ? a[i] : None(); }
    size_t size() const { return t == Arr ? a.size() : t == Obj ? o.size() : 0; }
    bool isNull() const { return t == Null; }
    std::string str(const std::string& def = "") const { return t == Str ? s : def; }
    double num(double def = 0) const { return t == Num ? n : def; }
    bool boolean(bool def = false) const { return t == Bool ? b : def; }
};

namespace detail {
struct P {
    const char* p; const char* e; int depth = 0;
    void ws() { while (p < e && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++; }
    static void utf8(std::string& o, uint32_t c) {
        if (c < 0x80) o += (char)c;
        else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 63)); }
        else if (c < 0x10000) { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
        else { o += (char)(0xF0 | (c >> 18)); o += (char)(0x80 | ((c >> 12) & 63)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
    }
    bool hex4(uint32_t& v) {
        if (e - p < 4) return false; v = 0;
        for (int i = 0; i < 4; i++) { char c = *p++; v <<= 4; if (c >= '0' && c <= '9') v |= c - '0'; else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10; else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10; else return false; }
        return true;
    }
    bool str(std::string& o) {
        if (p >= e || *p != '"') return false; p++;
        while (p < e) {
            unsigned char c = (unsigned char)*p++;
            if (c == '"') return true;
            if (c != '\\') { o += (char)c; continue; }
            if (p >= e) return false;
            char x = *p++;
            switch (x) {
                case 'n': o += '\n'; break; case 't': o += '\t'; break; case 'r': o += '\r'; break; case 'b': o += '\b'; break; case 'f': o += '\f'; break;
                case '/': case '\\': case '"': o += x; break;
                case 'u': { uint32_t u; if (!hex4(u)) return false;
                    if (u >= 0xD800 && u < 0xDC00 && e - p >= 6 && p[0] == '\\' && p[1] == 'u') { p += 2; uint32_t lo; if (!hex4(lo)) return false; if (lo >= 0xDC00 && lo < 0xE000) u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00); }
                    utf8(o, u); break; }
                default: return false;
            }
        }
        return false;
    }
    bool val(Val& v) {
        ws(); if (p >= e || ++depth > 32) return false;
        struct D { int& d; ~D() { d--; } } dd{depth};
        const char c = *p;
        if (c == '{') {
            p++; v.t = Val::Obj; ws();
            if (p < e && *p == '}') { p++; return true; }
            for (;;) {
                ws(); std::string k; if (!str(k)) return false; ws();
                if (p >= e || *p++ != ':') return false;
                Val x; if (!val(x)) return false; v.o.emplace_back(std::move(k), std::move(x)); ws();
                if (p >= e) return false;
                if (*p == ',') { p++; continue; }
                if (*p == '}') { p++; return true; }
                return false;
            }
        }
        if (c == '[') {
            p++; v.t = Val::Arr; ws();
            if (p < e && *p == ']') { p++; return true; }
            for (;;) {
                Val x; if (!val(x)) return false; v.a.push_back(std::move(x)); ws();
                if (p >= e) return false;
                if (*p == ',') { p++; continue; }
                if (*p == ']') { p++; return true; }
                return false;
            }
        }
        if (c == '"') { v.t = Val::Str; return str(v.s); }
        if (e - p >= 4 && !strncmp(p, "true", 4)) { p += 4; v.t = Val::Bool; v.b = true; return true; }
        if (e - p >= 5 && !strncmp(p, "false", 5)) { p += 5; v.t = Val::Bool; v.b = false; return true; }
        if (e - p >= 4 && !strncmp(p, "null", 4)) { p += 4; v.t = Val::Null; return true; }
        if (c == '-' || (c >= '0' && c <= '9')) {
            char* end = nullptr; std::string tmp(p, (size_t)(e - p > 40 ? 40 : e - p)); v.n = strtod(tmp.c_str(), &end);
            if (end == tmp.c_str()) return false; p += end - tmp.c_str(); v.t = Val::Num; return true;
        }
        return false;
    }
};
} // namespace detail

inline bool Parse(const std::string& text, Val& out) {
    if (text.size() > (1u << 20)) return false;
    detail::P p{text.data(), text.data() + text.size()}; Val v;
    if (!p.val(v)) return false;
    p.ws(); if (p.p != p.e) return false;
    out = std::move(v); return true;
}

// JSON string literal (with quotes) for a UTF-8 string.
inline std::string Quote(const std::string& s) {
    std::string o = "\"";
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break; case '\\': o += "\\\\"; break; case '\n': o += "\\n"; break; case '\r': o += "\\r"; break; case '\t': o += "\\t"; break;
            default: if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o += (char)c;
        }
    }
    return o + "\"";
}
} // namespace mj
