// Deliberately broken plugin used by --test-plugins: its video filter and hotkey dereference NULL.
// Nocto must catch the access violation, disable this plugin and keep running. Not shipped in plugins\.
#include "nocto_plugin.h"
static int CrashProcess(void*, void*, void*, void*, uint32_t, uint32_t, const float*, double) { volatile int* p = nullptr; *p = 42; return 1; }
static void CrashKey(void*) { volatile int* p = nullptr; *p = 1; }
static const nocto_video_filter_desc kCrash = {"crash", "Crash Filter (test)", nullptr, 0, nullptr, nullptr, CrashProcess};
static const nocto_hotkey_desc kKey = {"crash_key", "Crash (test)", CrashKey, nullptr};
extern "C" NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI_V1; }
extern "C" NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    info->abi = NOCTO_PLUGIN_ABI_V1; info->name = "Crash Test"; info->version = "0.0.1"; info->author = "Nocto tests";
    host->register_video_filter(host->plugin, &kCrash);
    host->register_hotkey(host->plugin, &kKey);
    return 1;
}