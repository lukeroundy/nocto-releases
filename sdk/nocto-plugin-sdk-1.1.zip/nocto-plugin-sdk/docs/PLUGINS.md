# Nocto plugin SDK (ABI 2, SDK 1.1)

Header: [`sdk/include/nocto_plugin.h`](../sdk/include/nocto_plugin.h) (plain C, no dependencies besides `<stdint.h>`). ABI 2 is additive: plugins built for ABI 1 load unchanged.
Samples: [`sdk/samples/sample_source`](../sdk/samples/sample_source) (C++ DLL) and [`sdk/samples/shader_vignette`](../sdk/samples/shader_vignette) (shader-only).

## Installing plugins (users)

File > Plugins... has two buttons, no terminal needed:

- **Install from .zip...** pick a plugin `.zip`; Nocto checks it and shows the files it will install.
- **Browse plugins...** opens the plugin library. Nothing is fetched until you press *Load plugin list* (it reads `plugins.json` from https://lukeroundy.github.io/nocto-releases/). *Install* downloads the zip, checks it against the SHA-256 in the list, and installs it.

Both ask for confirmation first, and say that a plugin is a program with the same access to your PC as Nocto. Installs and removals (the *Remove* button on a plugin you installed) are staged and finish the next time Nocto starts, because a loaded DLL cannot be replaced while it runs. *Undo these changes* cancels what is waiting. Plugins from the second folder (next to the app) are not removable from the UI.

### The zip format (authors)

A plain zip, either flat or with one wrapping folder, containing only plugin files: `*.dll` (Windows), `*.so` (Linux), `*.json`, `*.hlsl`, `*.glsl`, `*.md`, `*.txt`. Ship both `name.dll` and `name.so` in one zip if you support both; the file for the other OS is ignored. Nocto refuses a zip with any other file type, a path that is absolute or contains `..`, names that are hidden or reserved on Windows (`NUL`, `CON`, ...), duplicate names (case-insensitively), more than 64 files, more than 64 MiB per file or 128 MiB in total, a bad CRC, a size that does not match what the zip declares, or a zip that has nothing for the running OS. Only stored and deflate compression are accepted. Nothing is extracted until the whole archive has been validated.

### The catalog (`plugins.json`)

```json
{ "schema": 1, "plugins": [ { "id": "twitch", "name": "Twitch", "kind": "native", "version": "1.0.0", "status": "available",
  "author": "...", "description": "...", "features": ["..."], "platforms": ["windows-x64", "linux-x64"],
  "downloads": [ { "platform": "windows-x64", "file": "twitch-1.0.0-windows-x64.zip", "url": "plugins/downloads/....zip", "sha256": "<64 hex>", "size": 123456 } ] } ] }
```

`platform` is `windows-x64`, `windows-arm64`, `linux-x64` or `any`. `url` may be relative to `plugins.json`; it must end up `https://`. An entry without a valid 64-hex `sha256` cannot be installed from the app. `status` other than `available` (for example `coming_soon`) is listed but not installable. The plugin is "installed" when a file named `<id>.dll|.so|.json` exists in the user plugin folder, so keep the file stem equal to `id`; a higher dotted `version` than the installed one shows as an update.

## Where plugins live

- `%LOCALAPPDATA%\Nocto\plugins\` (per user; File > Plugins... > *Open user plugins folder*)
- `<folder of Nocto.exe>\plugins\` (shipped samples)

Each `*.dll` is a code plugin, each `*.json` a shader-filter manifest. A file name may only be loaded once (the per-user folder wins).
Plugins are loaded at startup; enabling a plugin in the Plugins window loads it immediately, disabling stops every call into it immediately (a DLL stays mapped until Nocto restarts).

### Linux

Same ABI, same sources, same manifests. Differences:

- Folders: `~/.local/share/Nocto/plugins/` (or `$XDG_DATA_HOME/Nocto/plugins`, or `$NOCTO_CONFIG_DIR/plugins` when that is set) and `<folder of the nocto binary>/plugins/`. Code plugins are `*.so` (loaded with `dlopen`), shader manifests are `*.json` as on Windows.
- Graphics handles: there is no D3D11. `device` / `context` are NULL and an OpenGL 3.3 core context is current. An "SRV" is a `GL_TEXTURE_2D` name and an "RTV" is a framebuffer object name, both passed as `(void*)(uintptr_t)name` (see the header). Source textures are RGBA8 (the sample uploads BGRA with `GL_BGRA`), straight alpha, row 0 = top.
- Build a plugin: `g++ -shared -fPIC -O2 -Isdk/include my_plugin.cpp -o my_plugin.so -lGL` (CMake: `add_library(x MODULE ...)` with `PREFIX ""`).
- Shader plugins: the same HLSL file is translated to GLSL by the host (`float4`/`lerp`/`frac`/`Texture2D.Sample` etc. as on the built-in effects). Alternatively set `"glsl": "file.glsl"` in the manifest instead of `"shader"` and write `vec4 fx(vec4 pos, vec2 uv)` directly (`src`, `PARAM(i)`, `TEXSIZE`, `TIME` are available). A compile error shows up in the Plugins window and the plugin is not loaded.
- Crash isolation uses signal handlers (SIGSEGV/SIGBUS/SIGFPE/SIGILL/SIGABRT) + `siglongjmp`, so it catches faults in callbacks the same way. A stack overflow is not caught (no alternate signal stack), and the plugin's own state may be corrupt after a fault, so the plugin is disabled until restart.
- Not available on Linux: `register_script_engine` (returns 0).
- Test: `nocto --test-plugins` (uses `plugins/` and `plugins_test/` next to the binary; silent).

## Code plugins (DLL / .so)

Export three C functions (return `NOCTO_PLUGIN_ABI`, which is 2, if you use anything under "ABI 2" below; ABI-1-only plugins may keep returning 1):

```c
#include "nocto_plugin.h"
NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI; }
NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    info->abi = NOCTO_PLUGIN_ABI; info->name = "My Plugin"; info->version = "1.0.0"; info->author = "me";
    host->register_source(host->plugin, &my_source);          // any of the register_* calls
    return 1;
}
NOCTO_EXPORT void nocto_plugin_unload(void) {}                // optional
```

Build with MSVC x64 (`cl /LD /MT myplugin.cpp d3d11.lib /I sdk/include`) or add a CMake target like `nocto-sample-source`.
Descriptors and everything they point to must stay valid while the plugin is loaded (use `static const`).

| Feature | Descriptor | Thread | Notes |
|---|---|---|---|
| Source | `nocto_source_desc` | render | `render()` returns an `ID3D11ShaderResourceView*` (BGRA8/RGBA8, sRGB-encoded, straight alpha) and its size. Appears under Add Source > Plugins. |
| Video filter | `nocto_video_filter_desc` | render | `process(in_srv, out_rtv, w, h, values)`: draw into `out_rtv` (same size/format as input; FP16 on HDR canvases). Return 0 to pass through. Set all pipeline state you use. |
| Audio filter | `nocto_audio_filter_desc` | mixer | in-place interleaved float, 10 ms chunks, fixed rate/channels per instance |
| Output | `nocto_output_desc` | render / audio | receives every program frame (canvas SRV + pts) and the mixed audio while started from the Plugins window |
| Hotkey action | `nocto_hotkey_desc` | UI | listed under Settings > Hotkeys > Plugins |
| Script engine | `nocto_script_engine_desc` | — | reserved hook for future scripting; `register_script_engine` currently returns 0 |

All D3D11 pointers are passed as `void*`; the device is Nocto's shared device and the context is the immediate context, already locked for you — never block in render-thread callbacks.

### Settings UI

Describe settings as an array of `nocto_prop { id, label, type, def, min, max }` with type `NOCTO_PROP_FLOAT`, `INT`, `BOOL` or `COLOR` (0xRRGGBB stored as a float). Nocto draws sliders/checkboxes/colour pickers and passes the values as `const float*` in declared order to every call (`create`, `update`, `process`). Values are saved in the scene (`pluginParams` for sources, `p` for filters).

### Logging and errors

`host->log(host->plugin, NOCTO_LOG_INFO, "text")` writes to the Plugins window log and `%LOCALAPPDATA%\Nocto\plugins.log`.

### Crash isolation

Every call into a plugin runs inside a structured-exception guard. On an access violation (or any other SEH exception) the plugin is marked **Crashed**, its error (`crashed in video filter process (exception 0xC0000005)`) is shown and logged, and no further calls are made: sources draw nothing, filters pass video/audio through, outputs stop being fed. Nocto continues rendering, recording and streaming. This is a safety net, not a sandbox: a plugin can still corrupt memory or hang; only install plugins you trust.

## ABI 2: panels, settings, secrets, network, timers

Get an API table with `host->get_api(host->plugin, name, version)` (only when `host->abi >= 2`; it returns NULL when unknown). Every table starts with `uint32_t size`; check it before using a field you were not built against.

| Table | Gives you |
|---|---|
| `nocto.ui` v1 | Widgets for a panel: text, buttons, checkbox, text inputs (password / multiline), sliders, combo, tabs, child regions, progress bar, images, clipboard. All sizes are in dp (100% pixels): never pre-scale, Nocto scales to 300%. |
| `nocto.app` v1 | `register_panel` (a dock window, first-run dock hint), `register_menu_item`, `post_to_ui`, `post_to_ui_after` + `cancel_task` (timers, SDK 1.1), `open_url`, `get_stream_state`, `toast`, `now_ms`, textures |
| `nocto.storage` v1 | Per-plugin settings JSON (up to 1 MiB) and secrets |
| `nocto.net` v1 | Async HTTP(S) and WebSocket (ws/wss) clients, TLS included (WinHTTP on Windows, GnuTLS on Linux) |

**Threads.** Panel draw, menu, `post_to_ui` / timer tasks, HTTP completions and WebSocket events all run on the UI thread, one after another: state touched only from them needs no locks. Never block in them. `post_to_ui` (and `post_to_ui_after`, `cancel_task`, `get_stream_state`) are the only calls valid from another thread. Every callback is crash-guarded like the ABI-1 ones.

**Settings and secrets.** `settings_save` / `settings_load` keep any JSON text per plugin in Nocto's data folder; it is not part of scene exports or profiles. `secret_set/get/delete` store tokens and keys in Windows Credential Manager, or on Linux in the Secret Service (libsecret) with a 0600 file fallback when no keyring is running. Secrets are per plugin and key, never exported in profiles and never logged, so put nothing secret in the settings JSON.

**Network.** `http_request` returns an id (0 = could not start) and calls back once on the UI thread with status, headers and body (valid only during the callback). `http_cancel` guarantees no callback afterwards. `ws_open` calls `on_close` exactly once, including when the connection fails (code 1006). Redirects are followed (5), bodies are capped at 64 MiB.

**Stream state and timers.** `get_stream_state` tells you whether Nocto is streaming or recording and whether a destination is Twitch. `post_to_ui_after(plugin, delay_ms, fn, user)` is a timer checked once per frame; it returns an id for `cancel_task`.

### Example: the Twitch plugin

[`plugins/twitch`](../plugins/twitch) is a complete ABI 2 plugin and a good model: a *Twitch* menu and two dock panels (**Twitch Stream Info**, **Twitch Chat**) built with `nocto.ui`; OAuth *device code flow* through `nocto.net` (Nocto's public Twitch Client ID, no client secret, the user approves a code at twitch.tv/activate); tokens in `nocto.storage` secrets and settings in its JSON; the stream info editor (title, category search, tags, language) through the Helix API; chat through EventSub WebSocket plus Helix send, with an anonymous read-only IRC fallback when not signed in. Scopes requested: `channel:manage:broadcast user:read:chat user:write:chat`.

## Shader-only video filters

A manifest `<name>.json` next to an HLSL file:

```json
{ "id": "vignette", "name": "Vignette", "version": "1.0.0", "author": "me", "shader": "vignette.hlsl", "entry": "main",
  "params": [ { "id": "strength", "label": "Strength", "type": "float", "default": 0.6, "min": 0, "max": 1 } ] }
```

The shader is compiled (ps_5_0) when the plugin loads; compile errors are shown in the Plugins window. Nocto prepends:

```hlsl
Texture2D src : register(t0);  SamplerState samp : register(s0);   // input, linear clamp
cbuffer NoctoParams : register(b0) { float4 noctoP[4]; float4 noctoInfo; };
#define PARAM(i) ...   // manifest param i (up to 16)
#define TEXSIZE ...    // float2 size in pixels
#define TIME ...       // seconds
```

and draws a fullscreen triangle; the entry point gets `(float4 pos : SV_Position, float2 uv : TEXCOORD0)` and returns the output colour.

## Samples

- `sample_source.dll`: *Color Bars* source (colour, bar speed, width), *Simple Gain* audio filter, *Frame Counter* output (logs frames/audio on stop), *Color Bars: toggle bar* hotkey.
- `vignette.json` + `vignette.hlsl`: shader-only vignette with strength, radius and tint.
- `crash_test.dll`, `bad_shader.json` (tests only, in `plugins_test`): crash isolation and compile-error reporting.