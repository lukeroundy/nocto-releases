# Nocto Plugin SDK (ABI 1)

Documentation: https://lukeroundy.github.io/nocto-releases/plugins.html

| Path | What |
|---|---|
| `include/nocto_plugin.h` | the complete plugin C ABI (only depends on `<stdint.h>`) |
| `samples/sample_source/` | C++ DLL sample: Color Bars source, Simple Gain audio filter, Frame Counter output, hotkey |
| `samples/shader_vignette/` | shader-only video filter sample (`vignette.json` + `vignette.hlsl`, no compiler needed) |
| `template/my_plugin.cpp` | starting point: Invert video filter (D3D11 pixel shader) + hotkey |
| `CMakeLists.txt` | builds both DLLs; `nocto_add_plugin()` helper for your own |

Build (Visual Studio 2022 / Build Tools with the C++ workload, CMake 3.20+):

    cmake -S . -B build -A x64
    cmake --build build --config Release
    cmake --install build --config Release     # optional: copies into %LOCALAPPDATA%\Nocto\plugins

Then restart Nocto (or enable the plugin in File > Plugins...).

Linux (Nocto 0.6.0+, same ABI): plugins are shared libraries (`.so`) loaded from `~/.local/share/Nocto/plugins`. There is no D3D11: an OpenGL 3.3 context is current and textures are GL names (see the header). The sample builds with:

    g++ -shared -fPIC -O2 -Iinclude samples/sample_source/sample_source.cpp -o sample_source.so -lGL
