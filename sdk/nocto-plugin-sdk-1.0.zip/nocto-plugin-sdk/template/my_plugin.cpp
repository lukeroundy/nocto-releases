// Template Nocto plugin: an "Invert" video filter (D3D11 pixel shader) plus a hotkey action.
// Rename ids/names, then build with the SDK CMakeLists.txt. See https://lukeroundy.github.io/nocto-releases/plugins.html
#include "nocto_plugin.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <cstring>

static const nocto_host* g_host;
static void Log(int level, const char* m) { if (g_host) g_host->log(g_host->plugin, level, m); }

static const char kShader[] = R"(
cbuffer P : register(b0) { float amount; float3 pad; };
Texture2D src : register(t0); SamplerState samp : register(s0);
struct V { float4 pos : SV_Position; float2 uv : TEXCOORD0; };
V vs(uint id : SV_VertexID) { V o; o.uv = float2((id << 1) & 2, id & 2); o.pos = float4(o.uv * float2(2, -2) + float2(-1, 1), 0, 1); return o; }
float4 ps(V i) : SV_Target { float4 c = src.Sample(samp, i.uv); c.rgb = lerp(c.rgb, 1.0 - c.rgb, amount); return c; }
)";

struct Invert {
    ID3D11VertexShader* vs = nullptr; ID3D11PixelShader* ps = nullptr;
    ID3D11Buffer* cb = nullptr; ID3D11SamplerState* samp = nullptr;
};
template <class T> static void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }
static void InvertDestroy(void* p) {
    auto* f = static_cast<Invert*>(p);
    if (!f) return;
    SafeRelease(f->vs); SafeRelease(f->ps); SafeRelease(f->cb); SafeRelease(f->samp);
    delete f;
}
static bool Compile(const char* entry, const char* target, ID3DBlob** out) {
    ID3DBlob* err = nullptr;
    HRESULT hr = D3DCompile(kShader, sizeof(kShader) - 1, "my_plugin", nullptr, nullptr, entry, target, 0, 0, out, &err);
    if (FAILED(hr)) Log(NOCTO_LOG_ERROR, err ? (const char*)err->GetBufferPointer() : "D3DCompile failed");
    if (err) err->Release();
    return SUCCEEDED(hr);
}
static void* InvertCreate(void* device) {
    auto* dev = static_cast<ID3D11Device*>(device);
    auto* f = new Invert;
    ID3DBlob* vsb = nullptr; ID3DBlob* psb = nullptr;
    bool ok = Compile("vs", "vs_5_0", &vsb) && Compile("ps", "ps_5_0", &psb) &&
              SUCCEEDED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &f->vs)) &&
              SUCCEEDED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &f->ps));
    if (vsb) vsb->Release();
    if (psb) psb->Release();
    D3D11_BUFFER_DESC bd{16, D3D11_USAGE_DYNAMIC, D3D11_BIND_CONSTANT_BUFFER, D3D11_CPU_ACCESS_WRITE};
    D3D11_SAMPLER_DESC sd{}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP; sd.MaxLOD = D3D11_FLOAT32_MAX;
    ok = ok && SUCCEEDED(dev->CreateBuffer(&bd, nullptr, &f->cb)) && SUCCEEDED(dev->CreateSamplerState(&sd, &f->samp));
    if (!ok) { InvertDestroy(f); return nullptr; }   // NULL: Nocto passes the video through
    Log(NOCTO_LOG_INFO, "Invert filter created");
    return f;
}
static int InvertProcess(void* p, void* context, void* in_srv, void* out_rtv, uint32_t w, uint32_t h, const float* values, double) {
    auto* f = static_cast<Invert*>(p);
    if (!f) return 0;                                  // create failed -> pass through
    auto* ctx = static_cast<ID3D11DeviceContext*>(context);
    D3D11_MAPPED_SUBRESOURCE m{};
    if (FAILED(ctx->Map(f->cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) return 0;
    float c[4] = {values[0], 0, 0, 0}; memcpy(m.pData, c, sizeof c);
    ctx->Unmap(f->cb, 0);
    // Nocto does not preserve pipeline state: set everything this draw uses.
    auto* rtv = static_cast<ID3D11RenderTargetView*>(out_rtv);
    auto* srv = static_cast<ID3D11ShaderResourceView*>(in_srv);
    D3D11_VIEWPORT vp{0, 0, float(w), float(h), 0, 1};
    ctx->OMSetRenderTargets(1, &rtv, nullptr);
    ctx->OMSetBlendState(nullptr, nullptr, 0xFFFFFFFF);
    ctx->RSSetViewports(1, &vp);
    ctx->RSSetState(nullptr);
    ctx->IASetInputLayout(nullptr);
    ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ctx->VSSetShader(f->vs, nullptr, 0);
    ctx->PSSetShader(f->ps, nullptr, 0);
    ctx->PSSetConstantBuffers(0, 1, &f->cb);
    ctx->PSSetSamplers(0, 1, &f->samp);
    ctx->PSSetShaderResources(0, 1, &srv);
    ctx->Draw(3, 0);
    ID3D11ShaderResourceView* nul = nullptr;
    ctx->PSSetShaderResources(0, 1, &nul);           // unbind the input before Nocto reuses it as a target
    return 1;
}
static const nocto_prop kInvertProps[] = {{"amount", "Amount", NOCTO_PROP_FLOAT, 1.f, 0.f, 1.f}};
static const nocto_video_filter_desc kInvert = {"invert", "Invert (my plugin)", kInvertProps, 1, InvertCreate, InvertDestroy, InvertProcess};

static void Hello(void*) { Log(NOCTO_LOG_INFO, "Hello from my plugin"); }
static const nocto_hotkey_desc kHello = {"hello", "My plugin: say hello", Hello, nullptr};

extern "C" NOCTO_EXPORT uint32_t nocto_plugin_abi(void) { return NOCTO_PLUGIN_ABI; }
extern "C" NOCTO_EXPORT int nocto_plugin_load(const nocto_host* host, nocto_plugin_info* info) {
    if (host->abi != NOCTO_PLUGIN_ABI) return 0;
    g_host = host;
    info->abi = NOCTO_PLUGIN_ABI; info->name = "My Plugin"; info->version = "1.0.0"; info->author = "You";
    info->description = "Template: Invert video filter + hello hotkey.";
    if (!host->register_video_filter(host->plugin, &kInvert)) Log(NOCTO_LOG_WARN, "video filter not registered");
    host->register_hotkey(host->plugin, &kHello);
    return 1;
}
extern "C" NOCTO_EXPORT void nocto_plugin_unload(void) { g_host = nullptr; }
