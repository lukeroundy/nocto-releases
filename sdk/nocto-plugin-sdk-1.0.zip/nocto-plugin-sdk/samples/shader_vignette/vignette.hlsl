// Nocto shader filter. Provided by the host: Texture2D src, SamplerState samp, PARAM(i) (manifest params in order),
// TEXSIZE (float2 pixels), TIME (seconds). Input: SV_Position + TEXCOORD0 (0..1). Output: straight-alpha colour.
float3 Unpack(float c) { uint u = (uint)c; return float3((u >> 16) & 255, (u >> 8) & 255, u & 255) / 255.0; }
float4 main(float4 pos : SV_Position, float2 uv : TEXCOORD0) : SV_Target {
    float4 c = src.Sample(samp, uv);
    float2 d = (uv - 0.5) * float2(TEXSIZE.x / TEXSIZE.y, 1.0);
    float r = length(d) / (0.5 * length(float2(TEXSIZE.x / TEXSIZE.y, 1.0)));
    float v = 1.0 - PARAM(0) * smoothstep(PARAM(1) * 0.5, PARAM(1) * 1.33, r);
    c.rgb = lerp(Unpack(PARAM(2)), c.rgb, v);
    return c;
}